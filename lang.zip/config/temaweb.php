<?php

return [
    'creditos' => 'Sistema de Practicas',

    'redes_sociales' => [
        'x' => '#',
        'facebook' => '#',
        'likedin' => '#',
    ],
];
